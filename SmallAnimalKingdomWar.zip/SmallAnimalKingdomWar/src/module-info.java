/**
 * 
 */
/**
 * 
 */
module SmallAnimalKingdomWar {
}